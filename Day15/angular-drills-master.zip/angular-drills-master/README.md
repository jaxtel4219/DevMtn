# angular-drills

``1``
Create an basic angular app where you type in a text box and it shows up as text somewhere else on the screen.

``2``
Create an app where there is an array of data in the service that is shown on the screen as a list

``3``
Create an app where there is a list of data on the screen (stored in a service) where you can type to filter what's shown in the list

``4``
Create an app hitting an api (swapi.co, birdapi.com, pokeapi, marvel api, etc)

``5``
Make a larger app if you have time.
